export const VERSION_METAMASK  = 'MetaMask';
export const VERSION_RAILS_API = 'RailsApi';
