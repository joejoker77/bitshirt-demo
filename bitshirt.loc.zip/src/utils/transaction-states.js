export const STATE_PENDING   = 'pending';
export const STATE_SUCCEEDED = 'succeeded';
export const STATE_FAILED    = 'failed';
