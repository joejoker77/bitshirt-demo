export default process.config;
