export const TYPE_BUY_PRODUCT   = 'BuyProduct';
export const TYPE_BECOME_MEMBER = 'BecomeMember';
export const TYPE_PUT_IN_SALE   = 'PutUpInSale';
export const TYPE_CHANGE_OWNER  = 'ChangeOwner';
