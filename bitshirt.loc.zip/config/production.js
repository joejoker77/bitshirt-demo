const productionConfig = {
  apiEndpoint: 'http://bitshirt.co/api'
}
module.exports = productionConfig;
