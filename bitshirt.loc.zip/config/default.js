const defaultConfig = {
  apiEndpoint: 'http://localhost:3000/api'
};
module.exports = defaultConfig;
